## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(AllPackages)

## -----------------------------------------------------------------------------

# Learning mdoel used on dataset

#my-db.sqlite <- Functoion()


