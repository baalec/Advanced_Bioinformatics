# AllPackages

**AllPackages** is an R toolkit that lets you …

- 🔍 Easily one-hot encode categorical variables
- 🧰 Connect to your local SQLite DB with helper functions
- 📊 Quickly generate summary reports

## Installation

```r

